export PUB_HOSTED_URL="https://pub.dev"
dart pub publish