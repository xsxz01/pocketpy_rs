#pragma once

#include <stdint.h>
#include "pocketpy/common/str.h"

void py_Name__initialize();
void py_Name__finalize();
