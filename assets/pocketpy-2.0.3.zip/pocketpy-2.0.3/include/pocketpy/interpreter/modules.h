#pragma once

void pk__add_module_os();
void pk__add_module_sys();
void pk__add_module_math();
void pk__add_module_dis();
void pk__add_module_random();
void pk__add_module_json();
void pk__add_module_gc();
void pk__add_module_time();
void pk__add_module_easing();
void pk__add_module_traceback();
void pk__add_module_enum();
void pk__add_module_inspect();

void pk__add_module_linalg();
void pk__add_module_array2d();

void pk__add_module_conio();
void pk__add_module_pkpy();