import sys

assert len(sys.argv) == 2
assert (sys.argv[1] == 'tests/80_sys.py'), sys.argv
