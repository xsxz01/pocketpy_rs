from ._b import C

def add(a, b):
    return a + b + C