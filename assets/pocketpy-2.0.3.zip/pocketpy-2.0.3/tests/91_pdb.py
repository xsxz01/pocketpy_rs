# a = 1
# b = 2

# print(a, b)


# def f(a, b):
#     b = a + b
#     print(a, b)
#     return b

# def g(a, b):
#     breakpoint()
#     c = f(a, b)
#     return c

# g(1, 2)
# f(3, 4)

