raise ValueError(
    "test3.a should not be imported"
)