raise ValueError(
    "test3 should not be imported"
)