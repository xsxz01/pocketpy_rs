from .r import value

def get_value_2():
    return value