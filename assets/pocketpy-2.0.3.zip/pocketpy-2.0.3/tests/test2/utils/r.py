value = '123'

from test2.a import g
assert g.ok
