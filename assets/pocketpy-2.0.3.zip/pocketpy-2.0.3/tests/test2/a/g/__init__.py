ok = True

from ...utils import r

def get_value():
    return r.value

class A:
    pass