---
icon: package
label: gc
---


### `gc.collect()`

Invoke the garbage collector.