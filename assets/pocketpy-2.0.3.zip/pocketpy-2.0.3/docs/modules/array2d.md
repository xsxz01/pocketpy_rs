---
icon: package
label: array2d
---

Efficient general-purpose 2D array.

#### Source code

:::code source="../../include/typings/array2d.pyi" :::