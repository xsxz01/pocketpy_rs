---
icon: package
label: json
---

### `json.loads(data: str)`

Decode a JSON string into a python object.

### `json.dumps(obj) -> str`

Encode a python object into a JSON string.

