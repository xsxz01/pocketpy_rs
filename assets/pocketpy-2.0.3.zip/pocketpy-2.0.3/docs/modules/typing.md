---
icon: package
label: typing
---

Placeholder module for type hints.

#### Source code

:::code source="../../python/typing.py" :::