---
icon: package
label: traceback
---

### `traceback.print_exc() -> None`

Print the last exception and its traceback.

### `traceback.format_exc() -> str`

Return the last exception and its traceback as a string.
