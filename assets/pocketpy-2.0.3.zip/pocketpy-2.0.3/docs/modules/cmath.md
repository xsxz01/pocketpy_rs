---
icon: package
label: cmath
---

Mathematical functions for complex numbers.

https://docs.python.org/3/library/cmath.html

#### Source code

:::code source="../../python/cmath.py" :::