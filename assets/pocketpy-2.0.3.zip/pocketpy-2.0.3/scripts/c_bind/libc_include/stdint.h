#define size_t int

#define int8_t int
#define int16_t int
#define int32_t int
#define int64_t int

#define uint8_t unsigned
#define uint16_t unsigned
#define uint32_t unsigned
#define uint64_t unsigned