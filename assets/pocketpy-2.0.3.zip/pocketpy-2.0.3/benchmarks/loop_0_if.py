for i in range(10000000):
    if i > 0:
        pass
