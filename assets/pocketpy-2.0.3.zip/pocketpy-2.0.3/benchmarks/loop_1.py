for i in range(10000000):
    x = i