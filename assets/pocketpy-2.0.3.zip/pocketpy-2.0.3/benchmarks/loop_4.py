for k, v in {k: k for k in range(2000000)}.items():
    pass

