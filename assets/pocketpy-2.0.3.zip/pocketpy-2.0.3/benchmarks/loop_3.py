for i in range(10000000):
    x = i + 1
    y = x * 2
    z = y - 5
    a = x * y // z