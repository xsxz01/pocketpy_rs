for i in range(10000000):
    pass
