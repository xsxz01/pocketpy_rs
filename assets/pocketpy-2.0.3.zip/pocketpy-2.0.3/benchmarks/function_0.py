def f(a, b, c):
    pass

for i in range(10000000):
    f(1, 2, 3)
    f(1, 2, 3)
    f(1, 2, 3)
    f(1, 2, 3)
